const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient } = require("@aws-sdk/lib-dynamodb");

// Region hämtas automatiskt från din AWS-config/ENV (eu-north-1 via aws configure)
const client = new DynamoDBClient({});

const ddb = DynamoDBDocumentClient.from(client, {
  marshallOptions: {
    removeUndefinedValues: true, // skicka inte upp undefined-fält till DynamoDB
  },
  unmarshallOptions: {
    wrapNumbers: false, // returnera numbers som vanliga JS-nummer
  },
});

module.exports = ddb;
